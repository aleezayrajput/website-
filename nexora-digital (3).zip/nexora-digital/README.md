# Nexora Digital website

Static website: HTML, CSS and vanilla JavaScript. No backend, database, API or paid service.
The contact form opens WhatsApp with the visitor's details already typed in.

## Files

| File | What it does |
|---|---|
| `index.html` | Homepage with all sections |
| `project.html`, `project.js` | Portfolio project detail page (one page serves every project) |
| `style.css` | All styling |
| `script.js` | Menu, portfolio, form, WhatsApp links, animations |
| `config.js` | **Your details live here.** Phone, email, social links, projects, testimonials, stats |
| `assets/` | Icons, favicon, share image |
| `robots.txt`, `sitemap.xml` | For Google |
| `_headers` | Security and caching rules for Cloudflare |

## 1. Before you publish: edit `config.js`

Open `config.js` in any text editor (Notepad works) and change:

1. `whatsappNumber`: international format, digits only. `0300 1234567` becomes `"923001234567"`.
2. `displayPhone`, `email`, `location`, `hours`.
3. The four `social` links.

Until the WhatsApp number is real, the form shows a warning instead of opening WhatsApp.

### Portfolio
The six projects are labelled **Sample concept** on the site. To add real work, add an object to `projects` with `sample: false`, a real `image` (screenshot saved in `assets/projects/`), and `liveUrl`. Delete the samples when you have enough real work.

### Testimonials
`testimonials: []` shows clearly marked placeholders. Add real reviews only with the client's permission:
`{ quote: "Their words", name: "Client name", role: "Role, Company" }`

### Statistics
`stats: []` hides the counter band. Add real, provable numbers and the animated counters appear automatically:
`{ value: 25, suffix: "+", label: "Projects delivered" }`

## 2. Replace the domain name (SEO)

Search for `nexora-digital.pages.dev` and replace it with your real address in:
`index.html` (canonical, og:url, og:image, twitter:image, JSON-LD url), `robots.txt`, `sitemap.xml`.

## 3. Deploy to Cloudflare Pages (free)

### Option A: drag and drop (easiest, no GitHub)
1. Create a free account at <https://dash.cloudflare.com>.
2. Go to **Workers & Pages**, then **Create application**, then choose the **Pages** drag-and-drop upload option.
3. Name the project, for example `nexora-digital`. Your site will be `nexora-digital.pages.dev`.
4. Drag in the whole `nexora-digital` folder (or `nexora-digital.zip`). Click **Deploy site**.
5. To update later: open the project, **Create a new deployment**, upload again.

Drag and drop allows up to 1,000 files and 25 MiB per file. This site uses about 20.

### Option B: GitHub (auto-deploys on every change)
1. Create a GitHub repository and upload these files to it.
2. In Cloudflare: **Workers & Pages**, **Create**, **Connect to Git**, choose the repository.
3. Framework preset: **None**. Build command: leave empty. Output directory: `/`.
4. Click **Save and Deploy**. After this, every commit goes live automatically.

### Custom domain (optional)
In your Pages project open **Custom domains**, then **Set up a custom domain**, and follow the DNS steps. A `.pk` or `.com` domain is bought separately from a registrar; Cloudflare's hosting and SSL are free.

## 4. After going live

1. Open the site on your phone and send yourself a test message from the form.
2. Submit `https://yourdomain/sitemap.xml` in Google Search Console.
3. Create a Google Business Profile for local searches.
4. Check speed at <https://pagespeed.web.dev>.

## Notes

- Fonts (Poppins, Inter) load from Google Fonts. Everything else is self-hosted.
- Form details go straight to WhatsApp and are not stored on any server.
- The site respects "reduce motion" settings and works with a keyboard.
