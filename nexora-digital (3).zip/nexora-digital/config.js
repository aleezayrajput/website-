/* ==========================================================================
   NEXORA DIGITAL — SITE SETTINGS
   Edit this file to put your real details on the website.
   No build step needed: save, re-upload to Cloudflare Pages, done.
   ========================================================================== */

window.NEXORA_CONFIG = {
  /* ---------- Contact details (REPLACE ALL OF THESE) ---------- */

  // WhatsApp number in international format, digits only, no "+" and no spaces.
  // Pakistan example: 0300 1234567  ->  "923001234567"
  // While this is still the placeholder, the contact form shows a warning.
  whatsappNumber: "923703036005",

  // How the phone number is shown to visitors
  displayPhone: "+92 370 3036005",

  email: "aleezayrajput51@gmail.com",
  location: "Your City, Pakistan",
  hours: "Add your working hours here",

  /* ---------- Social links (REPLACE with your real pages) ---------- */
  social: {
    facebook: "https://www.facebook.com/YOUR_PAGE",
    instagram: "https://www.instagram.com/YOUR_PAGE",
    linkedin: "https://www.linkedin.com/company/YOUR_PAGE",
    youtube: "https://www.youtube.com/@YOUR_PAGE"
  },

  /* ---------- Message pre-filled on the floating WhatsApp button ---------- */
  floatingMessage:
    "Hello Nexora Digital! I'd like to discuss a website or digital marketing project.",

  /* ---------- Verified business statistics ----------
     Leave this list EMPTY until you have real, provable numbers.
     When you add items, an animated counter band appears automatically.
     Example item:  { value: 25, suffix: "+", label: "Projects delivered" }
     Only add figures you can back up. */
  stats: [],

  /* ---------- Client testimonials ----------
     Leave EMPTY until you have real reviews with permission to publish.
     Until then, the site shows clearly labelled placeholder cards.
     Example item:
       { quote: "Their exact words…", name: "Client name", role: "Role, Company" } */
  testimonials: [],

  /* ---------- Portfolio projects ----------
     These are SAMPLE CONCEPTS, clearly labelled on the site.
     To add a real project, copy one object, set sample: false, and fill it in.
     Optional real-work fields:
       image:   "assets/projects/my-shop.jpg"  (screenshot; replaces the CSS mockup)
       liveUrl: "https://client-site.com"
       results: ["Only real, verified outcomes go here"]
     layout options: corporate | store | landing | redesign | ads | seo
     category options must match one of the filter names below. */
  portfolioCategories: ["Business Websites", "E-commerce", "Landing Pages", "Redesign", "Marketing"],

  projects: [
    {
      slug: "sample-corporate-website",
      image: "assets/projects/corporate-website.jpg",
      sample: true,
      title: "Corporate Website",
      client: "Sample company",
      category: "Business Websites",
      layout: "corporate",
      hue: 265,
      services: ["Business Website Development", "SEO"],
      summary: "A clean, trust-building company website with service pages and clear enquiry paths.",
      brief: "A professional services firm needs a website that explains what it does in seconds and makes it easy for new clients to get in touch.",
      approach: [
        "Plain-language page structure built around what visitors ask first.",
        "Service pages written for search, with fast mobile loading.",
        "A WhatsApp and form enquiry path on every page."
      ],
      deliverables: ["Home, About, Services and Contact pages", "Mobile-first responsive layout", "On-page SEO setup", "Enquiry form and WhatsApp button"]
    },
    {
      slug: "sample-online-store",
      image: "assets/projects/online-store.jpg",
      sample: true,
      title: "Online Store",
      client: "Sample retail brand",
      category: "E-commerce",
      layout: "store",
      hue: 285,
      services: ["E-commerce Website Development"],
      summary: "A product-first store with simple browsing, clear pricing and an easy checkout flow.",
      brief: "A growing retail brand wants to sell online without a confusing shop. Products need to be easy to find and easy to order.",
      approach: [
        "Product grid and category structure planned around how customers shop.",
        "Short checkout with local payment and delivery options in mind.",
        "Product pages designed to load quickly on mobile data."
      ],
      deliverables: ["Product and category pages", "Cart and checkout flow", "Order enquiry via WhatsApp", "Mobile-first responsive layout"]
    },
    {
      slug: "sample-campaign-landing-page",
      image: "assets/projects/campaign-landing-page.jpg",
      sample: true,
      title: "Campaign Landing Page",
      client: "Sample service business",
      category: "Landing Pages",
      layout: "landing",
      hue: 250,
      services: ["Landing Page Design", "Facebook & Instagram Ads"],
      summary: "One focused page with a single goal: turn ad clicks into enquiries.",
      brief: "A service business runs paid ads and needs a page that matches the ad promise and removes every distraction between click and enquiry.",
      approach: [
        "One offer, one message, one action.",
        "Headline and proof arranged to match the ad that sends the visitor.",
        "A short form that opens WhatsApp with the lead's details."
      ],
      deliverables: ["Single conversion-focused page", "Short enquiry form", "Ad-to-page message match", "Fast-loading build"]
    },
    {
      slug: "sample-website-redesign",
      image: "assets/projects/website-redesign.jpg",
      sample: true,
      title: "Website Redesign",
      client: "Sample local business",
      category: "Redesign",
      layout: "redesign",
      hue: 275,
      services: ["Website Redesign", "SEO"],
      summary: "An outdated site rebuilt to look current, load fast and work on every phone.",
      brief: "A local business has a site that looks dated and is hard to use on mobile. It needs a fresh design without losing its existing search presence.",
      approach: [
        "Audit of the current pages, content and search visibility.",
        "New design and structure that keeps what already works.",
        "Redirect plan so existing links keep working after launch."
      ],
      deliverables: ["Content and page audit", "New responsive design", "Redirect plan", "Speed and mobile improvements"]
    },
    {
      slug: "sample-social-ads-campaign",
      image: "assets/projects/social-ads-campaign.jpg",
      sample: true,
      title: "Social Ads Campaign",
      client: "Sample consumer brand",
      category: "Marketing",
      layout: "ads",
      hue: 300,
      services: ["Facebook & Instagram Ads", "Social Media Marketing"],
      summary: "Ad creatives and a posting plan built for Facebook and Instagram audiences in Pakistan.",
      brief: "A consumer brand wants steady enquiries from social media and needs ads and organic posts that speak to its local audience.",
      approach: [
        "Audience and offer planning before any ad is made.",
        "Creative variations tested against each other.",
        "Regular reporting in plain language."
      ],
      deliverables: ["Ad creatives and copy", "Audience setup", "Content calendar", "Monthly performance summary"]
    },
    {
      slug: "sample-seo-growth-plan",
      image: "assets/projects/seo-growth-plan.jpg",
      sample: true,
      title: "SEO Growth Plan",
      client: "Sample local service",
      category: "Marketing",
      layout: "seo",
      hue: 260,
      services: ["Search Engine Optimization (SEO)", "AI Content Creation"],
      summary: "Keyword research, on-page fixes and helpful content to be found for what customers search.",
      brief: "A local service business is invisible on Google for the searches its customers actually make.",
      approach: [
        "Keyword research in English and Roman Urdu where it matters.",
        "On-page and technical fixes to existing pages.",
        "New content that answers real customer questions."
      ],
      deliverables: ["Keyword map", "On-page and technical fixes", "Content plan", "Google Business Profile setup"]
    }
  ]
};
