/* Nexora Digital — project detail page. Reads project data from config.js */
(function () {
  "use strict";
  var CFG = window.NEXORA_CONFIG || {};
  var projects = CFG.projects || [];
  var root = document.getElementById("project-root");
  if (!root) return;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function list(items) {
    var ul = el("ul");
    (items || []).forEach(function (t) { ul.appendChild(el("li", null, t)); });
    return ul;
  }
  function block(title, content) {
    var s = el("section");
    s.appendChild(el("h2", null, title));
    s.appendChild(content);
    return s;
  }

  var digits = String(CFG.whatsappNumber || "").replace(/\D/g, "");
  function wa(msg) { return "https://wa.me/" + digits + "?text=" + encodeURIComponent(msg); }
  var floatBtn = document.getElementById("wa-float");
  if (floatBtn) floatBtn.href = wa(CFG.floatingMessage || "Hello Nexora Digital!");
  var y = document.getElementById("year");
  if (y) y.textContent = new Date().getFullYear();

  var slug = new URLSearchParams(window.location.search).get("p");
  var idx = -1;
  projects.forEach(function (p, i) { if (p.slug === slug) idx = i; });

  if (idx < 0) {
    var miss = el("div", "pp-missing");
    miss.appendChild(el("h1", null, "Project not found"));
    miss.appendChild(el("p", null, "This project link doesn't match anything in our portfolio."));
    var back = el("a", "btn btn-primary", "Back to portfolio");
    back.href = "index.html#portfolio";
    miss.appendChild(back);
    root.appendChild(miss);
    return;
  }

  var p = projects[idx];
  document.title = p.title + (p.sample ? " (Sample Concept)" : "") + " | Nexora Digital";
  var md = document.querySelector('meta[name="description"]');
  if (md) md.setAttribute("content", p.summary);

  var crumbs = el("nav", "crumbs");
  crumbs.setAttribute("aria-label", "Breadcrumb");
  crumbs.innerHTML = '<a href="index.html">Home</a><span aria-hidden="true">/</span><a href="index.html#portfolio">Portfolio</a><span aria-hidden="true">/</span>';
  crumbs.appendChild(el("span", null, p.title));
  root.appendChild(crumbs);

  var head = el("div", "pp-head");
  head.appendChild(el("h1", null, p.title));
  head.appendChild(el("p", "lead", p.summary));
  if (p.sample) {
    head.appendChild(el("p", "sample-note", "This is a sample concept created to show how we plan and design. It is not a real client project."));
  }
  root.appendChild(head);

  var stage = el("div", "pp-stage");
  if (p.image) {
    var img = el("img");
    img.src = p.image; img.alt = p.title + " website screenshot";
    stage.appendChild(img);
  } else {
    var b = el("div", "browser");
    b.style.setProperty("--h", p.hue || 265);
    b.setAttribute("aria-hidden", "true");
    b.innerHTML = '<div class="browser-bar"><i></i><i></i><i></i><span class="url">' + (p.liveUrl ? p.liveUrl.replace(/^https?:\/\//, "") : "yourclient.pk") + '</span></div><div class="browser-body" style="padding:24px;gap:18px">' +
      '<div class="mk-nav"><b></b><span></span><span></span><span></span></div>' +
      '<div class="mk-hero"><div class="mk-lines"><em class="w90"></em><em class="w70"></em><em class="w50"></em><u></u></div><div class="mk-art"></div></div>' +
      '<div class="mk-cards"><div></div><div></div><div></div></div></div>';
    stage.appendChild(b);
  }
  root.appendChild(stage);

  var grid = el("div", "pp-grid");
  var main = el("div", "pp-main");
  main.appendChild(block("The brief", el("p", null, p.brief)));
  main.appendChild(block("Our approach", list(p.approach)));
  main.appendChild(block("What's included", list(p.deliverables)));
  if (p.results && p.results.length) main.appendChild(block("Results", list(p.results)));

  var side = el("aside", "glass pp-side");
  var dl = el("dl");
  dl.style.cssText = "display:grid;gap:16px;margin:0";
  function row(k, v) { var d = el("div"); d.appendChild(el("dt", null, k)); d.appendChild(el("dd", null, v)); dl.appendChild(d); }
  row("Client", p.client);
  row("Category", p.category);
  row("Services", (p.services || []).join(", "));
  side.appendChild(dl);
  var ask = "Hello Nexora Digital! I saw the \"" + p.title + "\" project and I'd like something similar.";
  var cta = el("a", "btn btn-gold btn-block", "Start a similar project");
  cta.href = "index.html#contact";
  side.appendChild(cta);
  if (p.liveUrl) {
    var live = el("a", "btn btn-ghost btn-block", "Visit live site");
    live.href = p.liveUrl; live.target = "_blank"; live.rel = "noopener";
    side.appendChild(live);
  }
  var chat = el("a", "btn btn-ghost btn-block", "Ask on WhatsApp");
  chat.href = wa(ask); chat.target = "_blank"; chat.rel = "noopener";
  side.appendChild(chat);

  grid.appendChild(main);
  grid.appendChild(side);
  root.appendChild(grid);

  var nav = el("div", "pp-nav");
  if (idx > 0) {
    var pa = el("a"); pa.href = "project.html?p=" + encodeURIComponent(projects[idx - 1].slug);
    pa.appendChild(el("small", null, "Previous project")); pa.appendChild(el("b", null, projects[idx - 1].title));
    nav.appendChild(pa);
  }
  if (idx < projects.length - 1) {
    var na = el("a", "next"); na.href = "project.html?p=" + encodeURIComponent(projects[idx + 1].slug);
    na.appendChild(el("small", null, "Next project")); na.appendChild(el("b", null, projects[idx + 1].title));
    nav.appendChild(na);
  }
  root.appendChild(nav);
})();
