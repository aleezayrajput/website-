/* ==========================================================================
   Nexora Digital — site behaviour (vanilla JS, no dependencies)
   All editable details live in config.js
   ========================================================================== */
(function () {
  "use strict";

  var CFG = window.NEXORA_CONFIG || {};
  var doc = document;
  doc.documentElement.classList.add("js");

  function $(sel, ctx) { return (ctx || doc).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || doc).querySelectorAll(sel)); }
  function el(tag, cls, text) {
    var n = doc.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- WhatsApp helpers ---------- */
  function waDigits() { return String(CFG.whatsappNumber || "").replace(/\D/g, ""); }
  function waIsPlaceholder() {
    var d = waDigits();
    return !d || /X/i.test(String(CFG.whatsappNumber || "")) || d.length < 11;
  }
  function waUrl(message) {
    return "https://wa.me/" + waDigits() + "?text=" + encodeURIComponent(message);
  }

  /* ---------- Fill contact details from config ---------- */
  function applyConfig() {
    var floatMsg = CFG.floatingMessage || "Hello Nexora Digital!";
    $$("[data-wa-link]").forEach(function (a) {
      a.href = waUrl(floatMsg);
      var label = a.getAttribute("data-fill") === "displayPhone" && CFG.displayPhone;
      if (label) a.textContent = CFG.displayPhone;
    });
    var wa = $("#wa-float");
    if (wa) wa.href = waUrl(floatMsg);

    $$("[data-mail]").forEach(function (a) {
      if (CFG.email) { a.href = "mailto:" + CFG.email; a.textContent = CFG.email; }
    });
    $$("[data-fill]").forEach(function (n) {
      var key = n.getAttribute("data-fill");
      if (n.hasAttribute("data-wa-link") || n.hasAttribute("data-mail")) return;
      if (CFG[key]) n.textContent = CFG[key];
    });
    // Hide any detail that is still a placeholder, so visitors never see "Your City" etc.
    $$("[data-fill]").forEach(function (n) {
      if (/Your City|Add your|yourdomain|XXXX/i.test(n.textContent)) {
        var li = n.closest("li");
        if (li) li.hidden = true;
      }
    });
    var anySocial = false;
    $$("[data-social]").forEach(function (a) {
      var url = CFG.social && CFG.social[a.getAttribute("data-social")];
      var real = url && !/YOUR_PAGE/i.test(url);
      if (real) { a.href = url; anySocial = true; }
      else { var li = a.closest("li"); if (li) li.hidden = true; }
    });
    var soc = $(".social");
    if (soc && !anySocial) soc.hidden = true;
    var y = $("#year");
    if (y) y.textContent = new Date().getFullYear();
  }

  /* ---------- Sticky header ---------- */
  function initHeader() {
    var header = $(".site-header");
    var toggle = $("#menu-toggle");
    var nav = $("#nav");
    if (!header) return;

    var bar = $("#progress");
    function onScroll() {
      header.classList.toggle("scrolled", window.scrollY > 24);
      if (bar) {
        var max = doc.documentElement.scrollHeight - window.innerHeight;
        bar.style.transform = "scaleX(" + (max > 0 ? Math.min(window.scrollY / max, 1) : 0) + ")";
      }
    }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    if (!toggle || !nav) return;
    function setMenu(open) {
      nav.classList.toggle("open", open);
      header.classList.toggle("menu-open", open);
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      doc.body.style.overflow = open ? "hidden" : "";
    }
    toggle.addEventListener("click", function () { setMenu(toggle.getAttribute("aria-expanded") !== "true"); });
    $$("a", nav).forEach(function (a) { a.addEventListener("click", function () { setMenu(false); }); });
    doc.addEventListener("keydown", function (e) { if (e.key === "Escape") setMenu(false); });
    window.addEventListener("resize", function () { if (window.innerWidth > 1100) setMenu(false); });
  }

  /* ---------- Active nav link on scroll ---------- */
  function initScrollSpy() {
    var links = $$(".nav-list a[href^='#']");
    if (!links.length || !("IntersectionObserver" in window)) return;
    var map = {};
    links.forEach(function (a) { map[a.getAttribute("href").slice(1)] = a; });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          links.forEach(function (a) { a.classList.remove("active"); a.removeAttribute("aria-current"); });
          var a = map[en.target.id];
          if (a) { a.classList.add("active"); a.setAttribute("aria-current", "true"); }
        }
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    Object.keys(map).forEach(function (id) { var s = doc.getElementById(id); if (s) io.observe(s); });
  }

  /* ---------- Scroll reveal ---------- */
  function initReveal() {
    var items = $$(".reveal");
    if (!("IntersectionObserver" in window) || reduceMotion) {
      items.forEach(function (n) { n.classList.add("in"); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    items.forEach(function (n) { io.observe(n); });
  }

  /* ---------- Glass card spotlight ---------- */
  function initSpotlight() {
    if (reduceMotion || !window.matchMedia("(hover: hover)").matches) return;
    doc.addEventListener("pointermove", function (e) {
      var card = e.target.closest && e.target.closest(".glass");
      if (!card) return;
      var r = card.getBoundingClientRect();
      card.style.setProperty("--mx", e.clientX - r.left + "px");
      card.style.setProperty("--my", e.clientY - r.top + "px");
    }, { passive: true });
  }

  /* ---------- Portfolio mockups ---------- */
  function mockBody(layout) {
    var h = {
      corporate: '<div class="mk-nav"><b></b><span></span><span></span><span></span></div><div class="mk-hero"><div class="mk-lines"><em class="w90"></em><em class="w70"></em><em class="w50"></em><u></u></div><div class="mk-art"></div></div><div class="mk-cards"><div></div><div></div><div></div></div>',
      store: '<div class="mk-nav"><b></b><span></span><span></span></div><div class="mk-store"><div></div><div></div><div></div><div></div></div><div class="mk-store"><div></div><div></div><div></div><div></div></div>',
      landing: '<div class="mk-nav"><b></b><span></span></div><div class="mk-hero"><div class="mk-lines"><em class="w90"></em><em class="w70"></em><em class="w50"></em></div><div class="mk-form"><i></i><i></i><i></i><u></u></div></div><div class="mk-cards"><div></div><div></div><div></div></div>',
      redesign: '<div class="mk-split"><div><div class="mk-nav"><b></b><span></span></div><div class="mk-lines"><em class="w90"></em><em class="w50"></em></div></div><div><div class="mk-nav"><b></b><span></span><span></span></div><div class="mk-art"></div><div class="mk-lines"><em class="w70"></em><u></u></div></div></div><div class="mk-cards"><div></div><div></div><div></div></div>',
      ads: '<div class="mk-nav"><b></b><span></span></div><div class="mk-posts"><div></div><div></div><div></div></div><div class="mk-lines"><em class="w70"></em><em class="w50"></em></div>',
      seo: '<div class="mk-nav"><b></b><span></span></div><div class="mk-serp"><div><b></b><em></em><em></em></div><div><b></b><em></em><em></em></div><div><b></b><em></em><em></em></div></div>'
    };
    return h[layout] || h.corporate;
  }

  function mockup(p, big) {
    var wrap = el("div", "browser");
    wrap.style.setProperty("--h", p.hue || 265);
    wrap.setAttribute("aria-hidden", "true");
    var bar = el("div", "browser-bar");
    bar.innerHTML = "<i></i><i></i><i></i>";
    var url = el("span", "url", p.liveUrl ? p.liveUrl.replace(/^https?:\/\//, "") : "yourclient.pk");
    bar.appendChild(url);
    var body = el("div", "browser-body");
    body.innerHTML = mockBody(p.layout);
    wrap.appendChild(bar);
    wrap.appendChild(body);
    return wrap;
  }

  function projectThumb(p) {
    var t = el("div", "project-thumb");
    if (p.image) {
      var img = el("img");
      img.src = p.image;
      img.alt = p.title + " website screenshot";
      img.loading = "lazy";
      img.width = 800; img.height = 550;
      t.appendChild(img);
    } else {
      t.appendChild(mockup(p));
    }
    if (p.sample) t.appendChild(el("span", "project-badge", "Sample concept"));
    var ov = el("span", "project-overlay");
    ov.appendChild(el("span", null, "View project details"));
    ov.insertAdjacentHTML("beforeend", '<svg class="ico" aria-hidden="true"><use href="assets/icons.svg#i-arrow"/></svg>');
    t.appendChild(ov);
    return t;
  }

  function initPortfolio() {
    var grid = $("#portfolio-grid");
    var filters = $("#filters");
    if (!grid || !filters) return;
    var projects = CFG.projects || [];
    var cats = ["All"].concat(CFG.portfolioCategories || []);

    cats.forEach(function (c, i) {
      var b = el("button", "chip", c);
      b.type = "button";
      b.setAttribute("aria-pressed", i === 0 ? "true" : "false");
      b.addEventListener("click", function () {
        $$(".chip", filters).forEach(function (x) { x.setAttribute("aria-pressed", "false"); });
        b.setAttribute("aria-pressed", "true");
        $$(".project", grid).forEach(function (card) {
          var show = c === "All" || card.getAttribute("data-cat") === c;
          card.classList.toggle("is-hidden", !show);
        });
      });
      filters.appendChild(b);
    });

    projects.forEach(function (p) {
      var a = el("a", "project");
      a.href = "project.html?p=" + encodeURIComponent(p.slug);
      a.setAttribute("data-cat", p.category);
      a.setAttribute("aria-label", p.title + (p.sample ? " (sample concept)" : "") + ", view details");
      var card = el("div", "glass project-card");
      card.appendChild(projectThumb(p));
      var info = el("div", "project-info");
      info.appendChild(el("span", "cat", p.category));
      info.appendChild(el("h3", null, p.title));
      info.appendChild(el("p", null, p.summary));
      card.appendChild(info);
      a.appendChild(card);
      grid.appendChild(a);
    });
  }

  /* ---------- Testimonials: real ones only, otherwise labelled placeholders ---------- */
  function initTestimonials() {
    var grid = $("#testi-grid");
    var intro = $("#testi-intro");
    if (!grid) return;
    var list = CFG.testimonials || [];
    if (list.length) {
      if (intro) intro.textContent = "What our clients say about working with us.";
      list.forEach(function (t) {
        var fig = el("figure", "glass testi");
        fig.style.margin = "0";
        fig.appendChild(el("blockquote", null, "“" + t.quote + "”"));
        var cap = el("figcaption");
        cap.appendChild(el("b", null, t.name));
        if (t.role) cap.appendChild(el("span", null, t.role));
        fig.appendChild(cap);
        grid.appendChild(fig);
      });
      return;
    }
    if (intro) intro.textContent = "Reviews from real clients will appear here as projects are completed.";
    var box = el("div", "glass testi-empty reveal");
    var txt = el("div");
    txt.appendChild(el("h3", null, "Be one of our first success stories"));
    txt.appendChild(el("p", null, "We're building our client list. Start a project with Nexora Digital and get a clear plan, honest communication and a website you're proud of."));
    box.appendChild(txt);
    var cta = el("a", "btn btn-gold", "Get a Free Consultation");
    cta.href = "#contact";
    box.appendChild(cta);
    grid.appendChild(box);
  }

  /* ---------- Verified stats: counters appear only when stats are supplied ---------- */
  function initStats() {
    var sec = $("#stats");
    var grid = $("#stats-grid");
    var stats = CFG.stats || [];
    if (!sec || !grid || !stats.length) return;
    stats.forEach(function (s) {
      var li = el("li");
      var num = el("div", "stat-num");
      num.setAttribute("data-target", s.value);
      num.setAttribute("data-suffix", s.suffix || "");
      num.textContent = (reduceMotion ? s.value : 0) + (reduceMotion ? (s.suffix || "") : "");
      li.appendChild(num);
      li.appendChild(el("p", "stat-label", s.label));
      grid.appendChild(li);
    });
    sec.hidden = false;
    if (reduceMotion || !("IntersectionObserver" in window)) {
      $$(".stat-num", grid).forEach(function (n) { n.textContent = n.getAttribute("data-target") + n.getAttribute("data-suffix"); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        io.unobserve(en.target);
        var target = parseFloat(en.target.getAttribute("data-target"));
        var suffix = en.target.getAttribute("data-suffix");
        var start = null, dur = 1600;
        function step(ts) {
          if (start === null) start = ts;
          var t = Math.min((ts - start) / dur, 1);
          var eased = 1 - Math.pow(1 - t, 3);
          en.target.textContent = Math.round(target * eased) + suffix;
          if (t < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
      });
    }, { threshold: 0.4 });
    $$(".stat-num", grid).forEach(function (n) { io.observe(n); });
  }

  /* ---------- Service buttons preselect the form ---------- */
  function initServiceLinks() {
    var select = $("#f-service");
    if (!select) return;
    $$("[data-service]").forEach(function (a) {
      a.addEventListener("click", function () {
        var v = a.getAttribute("data-service");
        Array.prototype.forEach.call(select.options, function (o) { if (o.value === v || o.text === v) select.value = o.value || o.text; });
        clearError(select);
      });
    });
  }

  /* ---------- Contact form -> WhatsApp ---------- */
  var errBox = {};
  function clearError(input) {
    input.classList.remove("invalid");
    input.removeAttribute("aria-invalid");
    var e = $("#e-" + input.name);
    if (e) e.textContent = "";
  }
  function setError(input, msg) {
    input.classList.add("invalid");
    input.setAttribute("aria-invalid", "true");
    var e = $("#e-" + input.name);
    if (e) e.textContent = msg;
  }

  // Accepts 03XXXXXXXXX, 3XXXXXXXXX, +923XXXXXXXXX, 00923XXXXXXXXX and other countries' international numbers
  function validPhone(v) {
    var d = v.replace(/[\s\-()]/g, "");
    if (/^(\+|00)?92[0-9]{10}$/.test(d)) return true;
    if (/^0?3[0-9]{9}$/.test(d)) return true;
    if (/^(\+|00)[1-9][0-9]{7,14}$/.test(d)) return true;
    return false;
  }

  function initForm() {
    var form = $("#contact-form");
    if (!form) return;
    var status = $("#form-status");
    var fields = ["name", "email", "phone", "service", "budget", "details"].map(function (n) { return form.elements[n]; });

    fields.forEach(function (f) {
      f.addEventListener("input", function () { clearError(f); });
      f.addEventListener("change", function () { clearError(f); });
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      status.textContent = "";
      status.className = "form-status";
      var ok = true, firstBad = null;

      function bad(f, msg) { setError(f, msg); ok = false; if (!firstBad) firstBad = f; }

      var f = form.elements;
      var name = f.name.value.trim();
      var email = f.email.value.trim();
      var phone = f.phone.value.trim();
      var details = f.details.value.trim();

      if (name.length < 2) bad(f.name, "Please enter your full name.");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) bad(f.email, "Please enter a valid email address, like name@example.com.");
      if (!validPhone(phone)) bad(f.phone, "Please enter a valid WhatsApp number, like 0300 1234567 or +92 300 1234567.");
      if (!f.service.value) bad(f.service, "Please choose the service you need.");
      if (!f.budget.value) bad(f.budget, "Please choose a budget range.");
      if (details.length < 10) bad(f.details, "Please tell us a little about your project (at least 10 characters).");

      if (!ok) { firstBad.focus(); return; }

      if (waIsPlaceholder()) {
        status.className = "form-status warn";
        status.textContent = "The business WhatsApp number hasn't been set yet. Open config.js and replace whatsappNumber with your real number.";
        return;
      }

      var msg = [
        "Hello Nexora Digital! I'd like a free consultation.",
        "",
        "Name: " + name,
        "Email: " + email,
        "WhatsApp: " + phone,
        "Service: " + f.service.value,
        "Budget: " + f.budget.value,
        "",
        "Project details:",
        details
      ].join("\n");

      var url = waUrl(msg);
      var win = window.open(url, "_blank", "noopener");
      status.innerHTML = "";
      status.appendChild(doc.createTextNode(win ? "Opening WhatsApp. Tap Send to deliver your message. " : "Your browser blocked the new tab. "));
      var a = el("a", null, "Open WhatsApp manually");
      a.href = url; a.target = "_blank"; a.rel = "noopener";
      status.appendChild(a);
    });
  }

  /* ---------- Mouse parallax on hero mockups (desktop only) ---------- */
  function initParallax() {
    var vis = $(".hero-visual");
    if (!vis || reduceMotion || !window.matchMedia("(hover: hover) and (min-width: 881px)").matches) return;
    var hero = $(".hero");
    hero.addEventListener("pointermove", function (e) {
      var r = hero.getBoundingClientRect();
      var x = (e.clientX - r.left) / r.width - 0.5;
      var y = (e.clientY - r.top) / r.height - 0.5;
      vis.style.transform = "translate(" + x * -14 + "px," + y * -10 + "px)";
    }, { passive: true });
    hero.addEventListener("pointerleave", function () { vis.style.transform = ""; });
    vis.style.transition = "transform 0.6s cubic-bezier(0.22,1,0.36,1)";
  }

  /* ---------- Run ---------- */
  function boot() {
    applyConfig();
    initHeader();
    initScrollSpy();
    initPortfolio();
    initTestimonials();
    initStats();
    initServiceLinks();
    initForm();
    initSpotlight();
    initParallax();
    initReveal();
  }
  if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
